#!/bin/bash
if [ !(-f  /home/$USER/spark-1.6.0-bin-hadoop2.6 ) ];
	echo 'no existe'
else
	echo 'si existe'
fi
