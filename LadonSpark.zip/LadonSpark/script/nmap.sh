#!/bin/bash
if [ -f /usr/binnmap  ];

then
nmap -sP 192.168.0.0/24 -oX /home/antonio/prueba.xml

else
apt-get install nmap
nmap -sP $1 -oX $2

fi
