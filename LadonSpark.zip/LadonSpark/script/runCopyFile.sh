#!/bin/bash
ssh $2@$1 "sh copyFile.sh"
