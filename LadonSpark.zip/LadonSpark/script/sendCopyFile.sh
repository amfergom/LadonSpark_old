#!/bin/bash
scp web/copyFile.sh $2@$1:/home/$2
