#!/bin/bash
sh /home/$1/spark/bin/start-all.sh
