#!/bin/bash
hadoop fs -put $1 $2
