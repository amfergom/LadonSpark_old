/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author antonio
 */
public class Initial {
    public void executeScript(String netmask, String url) throws IOException, InterruptedException{
   
      // System.out.println(Runtime.getRuntime().exec("sh "+url+"script/nmap.sh",new String[]{netmask,url}).getErrorStream());  
  System.out.println(url);
  Process p;
   String xml=url+"src/java/model/prueba.xml";
   String script=url+"script/nmap.sh";
        System.out.println(netmask);
 /*
     p = new  ProcessBuilder("/bin/bash", script);
    // p.command(new String[]{script,netmask,url});
    final Process pro = p.start();
    */
        System.out.println("antes del comando");
    p=Runtime.getRuntime().exec("nmap -sP "+netmask+" -oX "+xml);
   
   p.waitFor();
        System.out.println("Despues del comando");
        p.destroyForcibly();
    }
    public void executeScript2(String netmask, String url) throws IOException, InterruptedException{
   
      // System.out.println(Runtime.getRuntime().exec("sh "+url+"script/nmap.sh",new String[]{netmask,url}).getErrorStream());  
  System.out.println(url);
  Process p;
  String s;
   String xml=url+"src/java/model/prueba.xml";
   String script=url+"script/nmap.sh";
          p = Runtime.getRuntime().exec("nmap -sP "+netmask+" -oX "+xml);
          p.waitFor();

                        BufferedReader stdInput = new BufferedReader(new InputStreamReader(
                                        p.getInputStream()));

                        BufferedReader stdError = new BufferedReader(new InputStreamReader(
                                        p.getErrorStream()));

                        // Leemos la salida del comando
                        System.out.println("Ésta es la salida standard del comando:\n");
                        while ((s = stdInput.readLine()) != null) {
                                System.out.println(s);
                        }

                        // Leemos los errores si los hubiera
                        System.out
                                        .println("Ésta es la salida standard de error del comando (si la hay):\n");
                        while ((s = stdError.readLine()) != null) {
                                System.out.println(s);
                        }
    }
    
}
