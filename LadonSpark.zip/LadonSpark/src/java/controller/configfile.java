/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import model.Host;
import model.dateConnect;
import org.jdom2.JDOMException;

/**
 *
 * @author antonio
 */
public class configfile {

    Loaddata ld;
    dateConnect dt = new dateConnect("antonio", "wlan0");

    public configfile() throws JDOMException, IOException {
        // this.ld = new Loaddata();
    }

    public void createCopyFile() throws IOException {
        String ruta = "../webapps/TFG/web/copyFile.sh";
        File archivo = new File(ruta);
        BufferedWriter bw;

        bw = new BufferedWriter(new FileWriter(archivo));
        String cadena = "#!/bin/bash\n"
                + "if [ -f  /home/" + dt.getUser() + "/spark-1.6.0-bin-hadoop2.6  ];\n"
                + "\n"
                + "then\n"
                + "cd spark-1.6.0-bin-hadoop2.6/conf\n"
                + "wget " + ld.getMasterHost().getIp() + ":8084/TFG/slave\n"
                + "wget " + ld.getMasterHost().getIp() + ":8084/TFG/spark-ev.sh\n"
                + "\n"
                + "else\n"
                + "wget " + ld.getMasterHost().getIp() + ":8084/TFG/spark-1.6.0-bin-hadoop2.6.tgz\n"
                + "tar -xvf spark-1.6.0-bin-hadoop2.6.tgz\n"
                + "cd spark-1.6.0-bin-hadoop2.6/conf\n"
                + "wget " + ld.getMasterHost().getIp() + ":8084/TFG/slave\n"
                + "wget " + ld.getMasterHost().getIp() + ":8084/TFG/spark-env.sh\n"
                + "fi";
        bw.write(cadena);
        bw.close();

    }

    public void callScriptCopyFile() throws IOException {

        for (int i = 0; i < ld.getHostfind().size(); i++) {
            ProcessBuilder p = new ProcessBuilder("/bin/bash", "script/sendCopyFile.sh", ld.getHostfind().get(i).getIp(), dt.getUser());
            final Process process = p.start();

            ProcessBuilder c = new ProcessBuilder("/bin/bash", "script/runCopyFile.sh", ld.getHostfind().get(i).getIp(), dt.getUser());
            final Process processss = c.start();

        }

    }

    public void sendConFile(List<Host> lh, String url, String useros) throws InterruptedException, IOException {
        Process p;
        for (int i = 0; i < lh.size(); i++) {
            p = Runtime.getRuntime().exec("scp "+useros+"@"+lh.get(i)+":"+url);
            if (p.waitFor() == 0) {

            }
        }
    }

    public void launchSpark() throws IOException {
        ProcessBuilder p = new ProcessBuilder("/bin/bash", "script/launchspark.sh", dt.getUser());
        final Process process = p.start();

    }
}
