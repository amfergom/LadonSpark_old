/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prueba;

import controller.ConexionSSH;
import controller.Initial;
import controller.Loaddata;
import controller.configfile;
import java.io.IOException;
import java.util.List;
import model.Host;
import org.jdom2.JDOMException;

/**
 *
 * @author antonio
 */
public class Prueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws JDOMException, IOException, InterruptedException {
       /* Initial init = new Initial();
        init.executeScript("192.168.0.0/24");
        Thread.sleep(20000);
        Loaddata cd = new Loaddata("");
        cd.removeHost(cd.getHostfind().get(0));
        cd.viewHost();
        
        
        configfile cf= new configfile();
        cf.createCopyFile();
        
        cf.callScriptCopyFile();
        
        ConexionSSH s = new ConexionSSH();
        */
    }

}
